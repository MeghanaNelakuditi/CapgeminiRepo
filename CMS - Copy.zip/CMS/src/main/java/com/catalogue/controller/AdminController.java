package com.catalogue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.catalogue.bean.Product;
import com.catalogue.service.IAdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	IAdminService iAdminService;
	
	@GetMapping("/login")
	public ResponseEntity<Boolean> checkLoginDetails(@RequestParam String userName, String password){
		if(iAdminService.checkLoginDetails(userName,password))
			return new ResponseEntity<Boolean>(true,HttpStatus.OK);
		return new ResponseEntity<Boolean>(false,HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/getallproducts")
	public ResponseEntity<?> getAllProducts(){
		List<Product> productList=iAdminService.getAllProducts();
		if(productList==null) {
			return new ResponseEntity(null,HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(productList,HttpStatus.OK);
	}
	
	@PostMapping("/addproduct")
	public ResponseEntity<Boolean> addProduct(@RequestBody Product product){
		System.out.println(product);
		String message=iAdminService.addPrductDetails(product);
		if(message==null) {
			return new ResponseEntity<Boolean>(false,HttpStatus.NOT_IMPLEMENTED);
		}
		return new ResponseEntity<Boolean>(true,HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteproduct")
	public ResponseEntity<Boolean> deleteProduct(@RequestParam String productId){
		if(iAdminService.deleteProductById(productId)!=null)
			return new ResponseEntity(true,HttpStatus.OK);
		return new ResponseEntity<Boolean>(false,HttpStatus.NOT_FOUND);
		}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/searchproduct")
	public ResponseEntity searchProduct(@RequestParam("searchterm") String searchTerm){
		System.out.println(searchTerm);
		List<Product> productList=iAdminService.searchProduct(searchTerm);
		if(productList!=null) 
		{
			return new ResponseEntity<List<Product>>(productList,HttpStatus.OK);
		}
		return new ResponseEntity(null,HttpStatus.NOT_FOUND);
	}
}
