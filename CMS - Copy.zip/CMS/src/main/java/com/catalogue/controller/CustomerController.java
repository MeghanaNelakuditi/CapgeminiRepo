package com.catalogue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.catalogue.bean.Customer;
import com.catalogue.bean.OrderInfo;
import com.catalogue.bean.Product;
import com.catalogue.bean.ProductInfo;
import com.catalogue.service.ICustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:4200") 
public class CustomerController {

	@Autowired
	ICustomerService customerService;
	
	@GetMapping("/getallproducts")
	public ResponseEntity<?> getAllProducts(){
		List<Product> productList=customerService.getAllProducts();
		if(productList==null) {
			return new ResponseEntity("No products found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(productList,HttpStatus.OK);
	}
	
	@PostMapping("/register")
	public ResponseEntity<String> registerCustomer(@RequestBody Customer customer) {
		if(customerService.addDetails(customer) != null)
			return new ResponseEntity<String>("Registered Successfully!!!",HttpStatus.OK);
		return new ResponseEntity<String>("Already a user is registered with the same email.......",HttpStatus.NOT_IMPLEMENTED);
	}
	
	@GetMapping("/login")
	public ResponseEntity<String> checkLoginDetails(@RequestParam String username, String password){
		if(customerService.checkLoginDetails(username,password))
			return new ResponseEntity<String>("Login Successfull!!!",HttpStatus.OK);
		return new ResponseEntity<String>("Invalid username or Password!!!",HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/cart")
	public ResponseEntity<String> addToCart(@RequestParam String userName, String productId){
			if(customerService.addToCart(userName,productId))
				return new ResponseEntity<String>("Product Added Successfully.......",HttpStatus.OK);
			return new ResponseEntity<String>("Product is not added to the cart",HttpStatus.NOT_FOUND);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/getcartdetails")
	public ResponseEntity<?> getCartDetails(@RequestParam String userName){
		List<ProductInfo> productList =customerService.getCartDetails(userName);
		if(productList!=null) {
			return new ResponseEntity(productList,HttpStatus.OK);
		}
		return new ResponseEntity<String>("cart is empty...",HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/deleteproductfromcart")
	public ResponseEntity<String> deleteProductFromCart(@RequestParam String userName,String productId){
		if(customerService.deleteProductFromCart(userName,productId)) {
			return new ResponseEntity<String>("deleted Successfully",HttpStatus.OK);

		}
		return new ResponseEntity<String>("product is not deleted.....",HttpStatus.NOT_FOUND);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/searchproductsbypricerange")
	public ResponseEntity<List<Product>> searchProductsByRange(@RequestParam int minPrice,int maxPrice){
		List<Product> productList=customerService.searchProductByRange(minPrice,maxPrice);
		if(productList==null) {
			return new ResponseEntity("No products found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(productList,HttpStatus.OK);
	}
	
	@GetMapping("/forgotpassword")
	public ResponseEntity<String> forgotPassword(@RequestParam String userName, String securityQuestion, String securityAnswer)
	{
		if(customerService.forgotPassword(userName,securityQuestion,securityAnswer)) 
		{
			return new ResponseEntity<String>("Successful",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Failure",HttpStatus.NOT_ACCEPTABLE);
	}
	
	@PostMapping("/changepassword")
	public ResponseEntity<String> changePassword(@RequestParam String userName,String password){
		if(customerService.changePassword(userName,password)) {
			return new ResponseEntity<String>("successfully changed",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Unable to change password",HttpStatus.NOT_IMPLEMENTED);
	}
	
	@SuppressWarnings("rawtypes")
	@PostMapping("/confirmorder")
	public ResponseEntity<OrderInfo> confirmOrder(@RequestBody String userName, List<ProductInfo> productList,Double totalPrice){
		OrderInfo orderInfo=customerService.confirmOrder(userName,productList,totalPrice);
		if(orderInfo!=null) {
			return new ResponseEntity<OrderInfo>(orderInfo,HttpStatus.OK);
		}
		return new ResponseEntity("Unsuccessful order",HttpStatus.NOT_IMPLEMENTED);
	}
}
