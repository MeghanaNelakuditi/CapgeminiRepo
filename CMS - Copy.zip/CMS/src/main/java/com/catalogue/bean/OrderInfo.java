package com.catalogue.bean;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class OrderInfo {
	@Id
	private String orderId;
	private List<ProductInfo> productInfo;

	public OrderInfo() {
	}
	public List<ProductInfo> getProductInfo() {
		return productInfo;
	}
	public void setProductInfo(List<ProductInfo> productInfo) {
		this.productInfo = productInfo;
	}
	public OrderInfo(String orderId, List<ProductInfo> productInfo, Double totalPrice) {
		super();
		this.orderId = orderId;
		this.productInfo = productInfo;
	}
}
